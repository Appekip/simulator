package testi;

import simu.framework.*;
import simu.framework.Trace.Level;
import simu.model.OmaMoottori;

public class Simulaattori{


	public static void main(String[] args) {
		
		
		view.SimulaattorinGUI.main(args);
		
		Trace.setTraceLevel(Level.INFO);
		
	
		 
	}
	
		

	
}
	
	